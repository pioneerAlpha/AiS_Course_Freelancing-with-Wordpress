<?php

	/*
	Plugin Name: Real3D Flipbook
	Plugin URI: https://codecanyon.net/item/real3d-flipbook-wordpress-plugin/6942587?ref=creativeinteractivemedia
	Description: Premium Responsive Real 3D FlipBook  
	Version: 3.35
	Author: creativeinteractivemedia
	Author URI: http://codecanyon.net/user/creativeinteractivemedia?ref=creativeinteractivemedia
	*/

	define('REAL3D_FLIPBOOK_VERSION', '3.33');
	define('REAL3D_FLIPBOOK_FILE', __FILE__);

	include_once( plugin_dir_path(__FILE__).'/includes/Real3DFlipbook.php' );