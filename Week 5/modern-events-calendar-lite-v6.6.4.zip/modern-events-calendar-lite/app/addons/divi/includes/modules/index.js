import MECShortcodes from './MECShortcodes/MECShortcodes';

export default [
    MECShortcodes,
];
