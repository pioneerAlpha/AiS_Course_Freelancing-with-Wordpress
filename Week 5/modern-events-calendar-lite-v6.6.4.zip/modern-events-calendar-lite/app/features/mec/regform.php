<?php
/** no direct access **/
defined('MECEXEC') or die();
?>