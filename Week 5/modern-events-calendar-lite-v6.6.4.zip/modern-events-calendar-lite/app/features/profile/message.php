<?php
/** no direct access **/
defined('MECEXEC') or die();
?>
<div class="mec-profile-message">
    <p><?php echo MEC_kses::element($message); ?></p>
</div>